			// Task 03:

	public class task3{
	public static void main (String [] args){
	String name="Ahad Ubed";
	int age=22;
	double avg=67.2;
	char gender='M';
	String frnr="Yes";
	int id=88;
	System.out.println("My name is "+name);
	System.out.println("My Age is "+age);
	System.out.println("My Average of CGP : "+avg);
	System.out.println("Gender : "+gender);
	System.out.println("Are you foreigner? : "+frnr);
	System.out.println("What is your id : "+id);
}
}