			// Task 01:
	
	public class task1{
	public static void main (String [] args){
  	System.out.println("////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	System.out.println("**	   student Points	**");
	System.out.println("////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	System.out.println("Name	      Lab     Bonus    Total");
	System.out.println("----	      ---     -----    -----");
	System.out.println("Joe		43	7	  50");
	System.out.println("Willaim		50	8	  58");
	System.out.println("Mary Sue	39	10	  49");
}
}