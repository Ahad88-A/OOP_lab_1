			// Task 09:
	import java.util.Scanner;
	
	public class task9{
	public static void main (String [] args){

	Scanner calculator=new Scanner (System.in);
	
	System.out.println("Enter First Number : ");
	double num1=calculator.nextDouble();
	
	System.out.println("Enter the second number : ");
	double num2=calculator.nextDouble();

	System.out.println("What do you want to : +,-,*,/ ");
	char operation=calculator.next().charAt(0);

	switch(operation){
	case '+':
	System.out.println("Result is = "+(num1+num2));
	break;
	case '-':
	System.out.println("Result is = "+(num1-num2));
 	break;
	case '*':
	System.out.println("Result is = "+num1*num2);
	break;
	case '/':
	System.out.println("Result is = "+num1/num2);
	break;
	default:
	System.out.println("Sorry! Invalid choice");

}
}
}
